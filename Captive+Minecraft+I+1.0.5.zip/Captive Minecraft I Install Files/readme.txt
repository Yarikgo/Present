
Thanks for downloading Captive Minecraft!

Make sure to check out thefarlanders.com/captiveminecraft for all information about getting the map up and running, and troubleshooting. To install, drag the folder “Captive Minecraft” into your world saves folder. No custom resource pack required.

As always, thanks for playing.


- Farlander

youtube.com/fromthefarlands
twitter.com/thefarlanders